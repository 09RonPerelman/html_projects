function handle1Click() {
  console.log('First square clicked');
}
